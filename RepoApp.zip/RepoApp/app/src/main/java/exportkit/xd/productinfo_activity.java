
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		untitled
	 *	@date 		1622117660948
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.xd;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class productinfo_activity extends Activity {

	
	private View _bg__productinfo_ek2;
	private ImageView ellipse_22_ek2;
	private View ellipse_21_ek4;
	private ImageView arrow_1_ek4;
	private ImageView rectangle_15;
	private TextView taco_s_ek1;
	private TextView lorem_ipsum_dolor_sit_amet__consectetur_adipiscing_elit__justo__pulvinar_integer_eleifend_consectetur_id_aliquam_egestas_lectus_pretium__dolor_lectus_ullamcorper_orci_nullam_quam_ac__in_imperdiet_mattis_id_amet__in_dui_vitae__ut_id_sit_at_ultricies_mauris_justo__cras_rhoncus_;
	private TextView _2020_12_27_ek3;
	private TextView acquisition_date_ek4;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.productinfo);

		
		_bg__productinfo_ek2 = (View) findViewById(R.id._bg__productinfo_ek2);
		ellipse_22_ek2 = (ImageView) findViewById(R.id.ellipse_22_ek2);
		ellipse_21_ek4 = (View) findViewById(R.id.ellipse_21_ek4);
		arrow_1_ek4 = (ImageView) findViewById(R.id.arrow_1_ek4);
		rectangle_15 = (ImageView) findViewById(R.id.rectangle_15);
		taco_s_ek1 = (TextView) findViewById(R.id.taco_s_ek1);

		_2020_12_27_ek3 = (TextView) findViewById(R.id._2020_12_27_ek3);
		acquisition_date_ek4 = (TextView) findViewById(R.id.acquisition_date_ek4);
	
		
		//custom code goes here
	
	}
}
	
	