
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		untitled
	 *	@date 		1622117660948
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.xd;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;


import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import org.jetbrains.annotations.NotNull;

import java.util.HashMap;

import exportkit.xd.models.Category;

    public class createcategory_activity extends Activity {
private EditText category,inputGoal;
private View backButton;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.createcategory);

		 category=findViewById(R.id.category);
		 inputGoal=findViewById(R.id.inputGoal);
		TextView add_ek1=findViewById(R.id.add_ek1);
		Button buttonView=findViewById(R.id.buttonView);


		add_ek1.setOnClickListener(v->
						{
					validatInput();
			});


		buttonView.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				startActivity(new Intent(createcategory_activity.this,firstwindow_activity.class));
			}
		});

		Button btn_viewCategory=findViewById(R.id.buttonView);
		btn_viewCategory.setOnClickListener(v->
				{
				Intent intent=new Intent(createcategory_activity.this,firstwindow_activity.class);
				startActivity(intent);
				});
	}
	private String name_of_category="", number_of_items_goal="";
	private void validatInput() {
			//get data
			name_of_category = category.getText().toString().trim();
			number_of_items_goal = inputGoal.getText().toString().trim();

			//validate data
			if (TextUtils.isEmpty(name_of_category)){
				Toast.makeText(this, "Enter category name", Toast.LENGTH_SHORT).show();

			}else if(TextUtils.isEmpty(number_of_items_goal)){
				Toast.makeText(this, "Enter number of items to store", Toast.LENGTH_SHORT).show();

			}
			else{
				//all data is valid to upload now
				addCategoryTofirebase();


			}
		}

		private String categoryIn="";
		private String goalIn="";
		private void addCategoryTofirebase() {
			long timestamp = System.currentTimeMillis();

			categoryIn=category.getText().toString().trim();
			goalIn=inputGoal.getText().toString().trim();
			//
			HashMap<String, Object> hashMap= new HashMap<>();
			hashMap.put("id",""+timestamp);
			hashMap.put("category",""+categoryIn);
			hashMap.put("goalItem",""+goalIn);
			hashMap.put("timestamp",timestamp);

			DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Categories");
			ref.child(""+timestamp)
					.setValue(hashMap)
					.addOnSuccessListener(new OnSuccessListener<Void>() {
						@Override
						public void onSuccess(Void unused) {
							Toast.makeText(createcategory_activity.this, "added good", Toast.LENGTH_SHORT).show();
						}
					})
			   .addOnFailureListener(new OnFailureListener() {
				   @Override
				   public void onFailure(@NonNull @NotNull Exception e) {
					   Toast.makeText(createcategory_activity.this, ""+e.getMessage(), Toast.LENGTH_SHORT).show();
				   }
			   });

		}
	}

