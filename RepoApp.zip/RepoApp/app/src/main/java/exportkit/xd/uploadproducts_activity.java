
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		untitled
	 *	@date 		1622117660948
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.xd;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;


import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.ImageView;

public class uploadproducts_activity extends Activity {


	private View _bg__uploadproducts_ek2;
	private View rectangle_10_ek1;
	private TextView choose_image____ek1;
	private TextView select_or_add_a_category_ek1;
	private TextView description_ek1;
	private View rectangle_11_ek1;
	private View rectangle_12_ek1;
	private View rectangle_1_ek7;
	private TextView upload_ek1;
	private View rectangle_6_ek3;
	private ImageView vector_ek17;
	private View ellipse_21_ek3;
	private ImageView arrow_1_ek3;
	private TextView acquisition_date_ek3;
	private View rectangle_14_ek2;
	private TextView _2020_12_27_ek2;

	public static final int TAKE_PIC_REQUEST_CODE = 0;
	public static final int CHOOSE_PIC_REQUEST_CODE = 1;
	public static final int MEDIA_TYPE_IMAGE = 2;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.uploadproducts);

		_bg__uploadproducts_ek2 = (View) findViewById(R.id._bg__uploadproducts_ek2);
		rectangle_1_ek7 = (View) findViewById(R.id.rectangle_1_ek7);
		ellipse_21_ek3 = (View) findViewById(R.id.ellipse_21_ek3);
		arrow_1_ek3 = (ImageView) findViewById(R.id.arrow_1_ek3);

	
		
		//custom code goes here

		ellipse_21_ek3.setOnClickListener(new View.OnClickListener() {

			public void onClick(View v) {

				startActivity(new Intent(uploadproducts_activity.this,firstwindow_activity.class));

			}
		});


		choose_image____ek1.setOnClickListener(new View.OnClickListener() {

			public void onClick(View v) {

				Intent pickPhoto = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
				//pickPhoto.setType("image/*");
				startActivityForResult(pickPhoto,1);



			}
		});

		rectangle_1_ek7.setOnClickListener(new View.OnClickListener() {

			public void onClick(View v) {

				startActivity(new Intent(uploadproducts_activity.this,categoryview_activity.class));



			}


		});
	}
}

