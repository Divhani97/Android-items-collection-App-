package exportkit.xd;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;

import exportkit.xd.adapters.AdapterItemAdmin;
import exportkit.xd.models.ModelItem;

public class ItemListAdminActivity extends AppCompatActivity {
    //arraylist to hold list of data of type ModelItem
    private ArrayList<ModelItem> itemArrayList;

    //
    private RecyclerView itemRv;

    //adapter
    private AdapterItemAdmin adapterItemAdmin;

    //
    private EditText searchEt;
    private TextView subTitleTv;
    private String categoryId,categoryTitle;
    private static final String TAG="ITEM_LIST_TAG";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_list_admin);

        subTitleTv = findViewById(R.id.subTitleTv);
        searchEt = findViewById(R.id.searchEt);
        itemRv = findViewById(R.id.itemRv);
        //itemRv.setHasFixedSize(true);

        //get data from intent
        Intent intent = new Intent();
        categoryId = intent.getStringExtra("categoryId");
        categoryTitle = intent.getStringExtra("categoryTitle");

        //set item category
        subTitleTv.setText(categoryTitle);

        loadItemList();

        //search
        searchEt.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                //search even as user inputs text
                try {
                    adapterItemAdmin.getFilter().filter(s);
                }

                    catch (Exception e){
                        Log.d(TAG, "onTextChanged: "+e.getMessage());
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

    }

    private void loadItemList() {

        //init list before adding data
        itemArrayList= new ArrayList<>();

        DatabaseReference  ref = FirebaseDatabase.getInstance().getReference("Items");
        /*ref.orderByChild("categoryId").equalTo(categoryId)*/
        ref .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        itemArrayList.clear();
                        for (DataSnapshot ds : snapshot.getChildren()){
                            //get data
                            ModelItem model=ds.getValue(ModelItem.class);

                            //add to list
                            itemArrayList.add(model);
                            Log.d(TAG, "onDataChange: "+model.getId()+" "+model.getTitle());
                          }

                        //setup adapter
                        adapterItemAdmin = new AdapterItemAdmin(ItemListAdminActivity.this,itemArrayList);
                        itemRv.setAdapter(adapterItemAdmin);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }
}