package exportkit.xd;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
/*import com.google.firebase.auth.FirebaseAuthException;*/
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.HashMap;

import exportkit.xd.models.Category;

public class ItemAddActivity extends AppCompatActivity {
   private EditText titleEt,descriptionEt;
   private TextView categoryTv;
   private Button submitBtn,pictureBtn,chartBtn;
    private ImageView imageView_item;
   private static final int PICK_IMAGE_REQUEST =1;

   //uri of picked image= null
   private Uri mImageUri = null;

   //progress dialog
    private ProgressDialog progressDialog;
   //firebase
    private FirebaseAuth firebaseAuth;

    //arraylist to hold categories
    private ArrayList<String> ArrayTitleList,ArrayIdList;


    //TAG for debugging
    private static final String TAG = "ADD_ITEM_TAG";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_item_add);

        imageView_item= findViewById(R.id.imageView_item);
        titleEt= findViewById(R.id.titleEt);
        descriptionEt= findViewById(R.id.descriptionEt);
        categoryTv= findViewById(R.id.categoryTv);
        submitBtn= findViewById(R.id.submitBtn);
        pictureBtn= findViewById(R.id.pictureBtn);
        chartBtn= findViewById(R.id.chartBtn);
        firebaseAuth= FirebaseAuth.getInstance();
        loadItemCategory();

        //setup progress dialog
        progressDialog= new ProgressDialog(this);
        progressDialog.setTitle("please wait");
        progressDialog.setCanceledOnTouchOutside(false);

        //handle clicking event to pick a category
        categoryTv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                categoryPickDialog();
            }
        });

        //handle add picture click
        pictureBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openFileChooser(); //pdfPickIntent()
            }
        });


        //handle click upload pdf
        //handle click upload complete item
        submitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              //validate data
              validateData();
            }
        });

        //
        chartBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               //go to pie chart
                startActivity(new Intent(ItemAddActivity.this,GraphicItems.class));
            }
        });

    }

    //pdfPickIntent
    private void openFileChooser() {

        Log.d(TAG, "openFileChooser: Starting image choosing intent");
            Intent intent=new Intent();
            intent.setType("image/*");
            intent.setAction(Intent.ACTION_GET_CONTENT);
            startActivityForResult(Intent.createChooser(intent,"select item image"), PICK_IMAGE_REQUEST);
        }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


        if (requestCode==PICK_IMAGE_REQUEST && resultCode==RESULT_OK && data !=null && data.getData() !=null){
            Log.d(TAG, "onActivityResult: image picked");

            mImageUri=data.getData();
            Log.d(TAG, "onActivityResult:  URI: "+mImageUri);
            Picasso.with(this).load(mImageUri).into(imageView_item); //imageView_item
        }
    }

    private String title="", description="";
    private void validateData() {
        //step 1:validate data
        Log.d(TAG, "validateData: validating data.....");

        //get data
        title = titleEt.getText().toString().trim();
        description = descriptionEt.getText().toString().trim();

        //validate data
        if (TextUtils.isEmpty(title)){
            Toast.makeText(this, "Enter tittle", Toast.LENGTH_SHORT).show();

        }else if(TextUtils.isEmpty(description)){
            Toast.makeText(this, "Enter Description", Toast.LENGTH_SHORT).show();

        }else if(TextUtils.isEmpty(selectedCategoryTitle)){
            Toast.makeText(this, "Pick Category", Toast.LENGTH_SHORT).show();
        }else if (mImageUri==null){
            Toast.makeText(this, "Pick an image", Toast.LENGTH_SHORT).show();
        }
        else{
            //all data is valid to upload now
            uploadItemToStorage();


        }
    }

    private void uploadItemToStorage() {
        //step 2:upload item to firebase storage
        Log.d(TAG, "uploadItemToStorage: uploading to storage");

        //show progress
        progressDialog.setMessage("uploading item....");
        progressDialog.show();

        //timestamp
        long timestamp=System.currentTimeMillis();

        //path of item in firebase storage
        String filePathAndName="Items/"+timestamp;
        //storage refererence
        StorageReference storageReference = FirebaseStorage.getInstance().getReference(filePathAndName);
        storageReference.putFile(mImageUri)
                .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                        Log.d(TAG, "onSuccess: Item uploaded to storage....");
                        Log.d(TAG, "onSuccess: getting item uri");

                        //get item uri
                        Task<Uri> uriTask= taskSnapshot.getStorage().getDownloadUrl();
                        while (!uriTask.isSuccessful());
                        String uploadedItemUri = ""+uriTask.getResult();

                        //upload to firebase db
                        uploadItemToDb(uploadedItemUri, timestamp);
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull  Exception e) {
                        progressDialog.dismiss();
                        Log.d(TAG, "onFailure: Item Upload failed due to "+e.getMessage());
                        Toast.makeText(ItemAddActivity.this, "Item Upload failed due to "+e.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });



    }

    private void uploadItemToDb(String uploadedItemUri, long timestamp) {
        //step 3: upload to firebase db
        Log.d(TAG, "uploadItemToDb: uploading item to firebase db");

        progressDialog.setMessage("uploading item into...");

        //set up data to upload
        HashMap<String,Object> hashMap= new HashMap<>();
        hashMap.put("id", ""+timestamp);
        hashMap.put("title", ""+title);
        hashMap.put("description", ""+description);
        hashMap.put("categoryId", ""+selectedCategoryId);
        hashMap.put("url", ""+uploadedItemUri);
        hashMap.put("timestamp", timestamp);

   //db reference: DB > Items.......
        DatabaseReference ref= FirebaseDatabase.getInstance().getReference("Items");
        ref.child(""+timestamp)
        .setValue(hashMap)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                        progressDialog.dismiss();
                        Log.d(TAG, "onSuccess: uploaded  ");
                        Toast.makeText(ItemAddActivity.this, "  uploaded", Toast.LENGTH_SHORT).show();

                    }
                })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull  Exception e) {
                            progressDialog.dismiss();
                            Log.d(TAG, "onFailure: failed to upload due to"+e.getMessage());
                            Toast.makeText(ItemAddActivity.this, " failed to upload : "+e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });

    }

    private void loadItemCategory() {
        Log.d(TAG,"loadItemCategory: Loading item category....");
        ArrayTitleList = new ArrayList<>();
        ArrayIdList= new ArrayList<>();

        //db reference to load categories
        DatabaseReference ref= FirebaseDatabase.getInstance().getReference("Categories");
        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                ArrayTitleList.clear();//clear before adding data
                ArrayIdList.clear();

                for (DataSnapshot ds: snapshot.getChildren()){
                    //getting id and title of the category from firebase db
                    String categoryId= ""+ ds.child("id").getValue();
                    String categoryTitle= ""+ ds.child("category").getValue();

                    //add to arraylists
                    ArrayTitleList.add(categoryTitle);
                    ArrayIdList.add(categoryId);

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }
        //the selected category title and id
    private String selectedCategoryTitle,selectedCategoryId;
    private void categoryPickDialog() {
        //
        Log.d(TAG, "categoryPickDialog: showing category pick dialog");

        //get string array of categories from arraylist
        String[] categoriesArray = new String[ArrayTitleList.size()];

        //loop
        for (int i = 0; i< ArrayTitleList.size(); i++){
            categoriesArray[i]= ArrayTitleList.get(i);
        }

        //alert dialog
        AlertDialog.Builder builder= new AlertDialog.Builder(this);
        builder.setTitle("Pick category")
                .setItems(categoriesArray, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        //handle item click

                        //get clicked item from the list of categories
                        selectedCategoryTitle = ArrayTitleList.get(which);
                        selectedCategoryId = ArrayIdList.get(which);

                        //set to category textview
                        categoryTv.setText(selectedCategoryTitle);

                        Log.d(TAG, "onClick:  selected Category: "+selectedCategoryId+" "+selectedCategoryTitle);
                    }
                })
                .show();
    }
}