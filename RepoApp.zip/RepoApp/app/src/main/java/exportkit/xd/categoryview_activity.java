
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		untitled
	 *	@date 		1622117660948
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.xd;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.ImageView;
import android.content.Intent;

import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

	public class categoryview_activity extends Activity {

	ImageView CategoryPlus=findViewById(R.id.CategoryPlus);
	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.categoryview);
		CategoryPlus.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
/*
				startActivity(new Intent(categoryview_activity.this,createcategory_activity.class));
*/
			}
		});
		



	}
}
	
	