package exportkit.xd.adapters;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.github.chrisbanes.photoview.PhotoView;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageMetadata;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;


import exportkit.xd.FilterItem;
import exportkit.xd.MyApplication;
import exportkit.xd.R;
import exportkit.xd.models.ModelItem;

import static exportkit.xd.Constants.MAX_BYTES_ITEM;

public class AdapterItemAdmin extends RecyclerView.Adapter<AdapterItemAdmin.HolderItemAdmin> implements Filterable {
    //context
    private Context context;

    //arraylist to hold list of data of the ModelItem
    public ArrayList<ModelItem> itemArrayList, filterList;

    //
    private FilterItem filter;
    private static final String TAG = "ITEM_ADAPTER_TAG";

    //constructor
    public AdapterItemAdmin(Context context, ArrayList<ModelItem> itemArrayList) {
        this.context = context;
        this.itemArrayList = itemArrayList;
        this.filterList = itemArrayList;
    }

    @NonNull
    @Override
    public HolderItemAdmin onCreateViewHolder(@NonNull  ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.row_item_admin,parent,false);
        return new AdapterItemAdmin.HolderItemAdmin(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterItemAdmin.HolderItemAdmin holder, int position) {
        //get the data
        ModelItem model=itemArrayList.get(position);

        String title= model.getTitle();
        String description= model.getDescription();
        long timestamp=model.getTimestamp();

        //convet timestanp to dd/mm/yyyy
        String formattedDate= MyApplication.formatTimestamp(timestamp);

        loadCategory(model,holder);
       loadItemFromUrl(model,holder);
        loadItemSize(model,holder);

        //seting the data
        holder.titleTv.setText(title);
        holder.descriptionTv.setText(description);
        holder.dateTv.setText(formattedDate);

    }

    private void loadItemSize(ModelItem model, HolderItemAdmin holder) {

        //using url to get file and its metadata from firebase
        String itemUrl = model.getUrl();
        StorageReference ref = FirebaseStorage.getInstance().getReferenceFromUrl(itemUrl);
        ref.getMetadata()
                .addOnSuccessListener(new OnSuccessListener<StorageMetadata>() {
                    @Override
                    public void onSuccess(StorageMetadata storageMetadata) {
                        //get size in bytes
                        double bytes = storageMetadata.getSizeBytes();

                        Log.d(TAG, "onSuccess: " +model.getTitle() +" "+bytes);

                        //convert bytes to KB
                        double kb = bytes/1024;
                        double mb = kb/1024;

                        if (mb >= 1){
                            holder.sizeTv.setText(String.format("%.2f",mb)+" MB");
                        } else if (kb >= 1){
                            holder.sizeTv.setText(String.format("%.2f",kb)+" KB");
                        }
                        else {
                            holder.sizeTv.setText(String.format("%.2f",bytes)+" bytes");
                        }
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull  Exception e) {
                        //failed getting metadata
                        Log.d(TAG, "onFailure: "+e.getMessage());
                       /* Toast.makeText(context, ""+e.getMessage(), Toast.LENGTH_SHORT).show();*/
                    }
                });
    }

    private void loadItemFromUrl(ModelItem model, HolderItemAdmin holder) {
        //using url to get file and its metadata from firebase

        String itemUrl= model.getUrl();
        StorageReference ref = FirebaseStorage.getInstance().getReferenceFromUrl(itemUrl);
        ref.getBytes(MAX_BYTES_ITEM)
                .addOnSuccessListener(new OnSuccessListener<byte[]>() {
                    @Override
                    public void onSuccess(byte[] bytes) {
                        Log.d(TAG, "onSuccess: "+model.getTitle()+" goodly got the file");
                        holder.progressBar.setVisibility(View.INVISIBLE);
                        Picasso.with(context)
                                .load(itemUrl)
                                .into(holder.itemViewItem);

                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull  Exception e) {
                        Log.d(TAG, "onFailure: failed to get file from url due to "+e.getMessage());
                    }
                });

    }

    private void loadCategory(ModelItem model, HolderItemAdmin holder) {

        //get category using category....categoryId
        String categoryId=model.getCategoryId();

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Categories");
        ref.child(categoryId)
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        //get category
                        String category= ""+snapshot.child("category").getValue();//

                        //set to category text view
                        holder.categoryTv.setText(category);

                    }

                    @Override
                    public void onCancelled(@NonNull  DatabaseError error) {

                    }
                });
    }

    @Override
    public int getItemCount() {
        return itemArrayList.size(); //return number of records . list size
    }

    @Override
    public Filter getFilter() {
        if (filter == null){
            filter = new FilterItem(filterList,this);

        }
        return filter;
    }

    //view holder class for row_item_admin.xml
    class HolderItemAdmin extends RecyclerView.ViewHolder{

        //Ui view of row_item_admin.xml
        PhotoView itemViewItem;
        ProgressBar progressBar;
        TextView titleTv, descriptionTv,categoryTv,sizeTv,dateTv;
        ImageButton moreBtn;

        public HolderItemAdmin(@NonNull  View itemView) {
            super(itemView);

            //init ui views
            itemViewItem = itemView.findViewById(R.id.itemViewItem);
            progressBar = itemView.findViewById(R.id.progressBar);
            titleTv  = itemView.findViewById(R.id.titleTv);
            descriptionTv  = itemView.findViewById(R.id.descriptionTv);
            categoryTv  = itemView.findViewById(R.id.categoryTv);
            sizeTv  = itemView.findViewById(R.id.sizeTv);
            dateTv  = itemView.findViewById(R.id.dateTv);
            moreBtn  = itemView.findViewById(R.id.moreBtn);

        }
    }

}
