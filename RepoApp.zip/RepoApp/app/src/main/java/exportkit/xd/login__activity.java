
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		untitled
	 *	@date 		1622117660948
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.xd;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.Bundle;


import android.os.Handler;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.content.Intent;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

	public class login__activity extends Activity {

		//firebase authentication
		private FirebaseAuth firebaseAuth;

		//progress dialog--show loading
		private ProgressDialog progressDialog;

	private Button btnLOGin;
	private View ellipse_21;
	private TextView username;
	private TextView password;



	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.login_);


		btnLOGin = findViewById(R.id.rectangle_1_ek1);
		username = (TextView) findViewById(R.id.username);
		password = (TextView) findViewById(R.id.password);
		TextView registerOption =findViewById(R.id.registerOption);

		//init firebase auth
		firebaseAuth = FirebaseAuth.getInstance();
		//setup progress dialog
		progressDialog = new ProgressDialog(this);
		progressDialog.setTitle("Please wait");
		progressDialog.setCanceledOnTouchOutside(false);


      //click event to register
		registerOption.setOnClickListener(new View.OnClickListener() {
		
			public void onClick(View v) {
				
				startActivity(new Intent(login__activity.this,signup_activity.class));
		
			}
		});

		//click event to register
		btnLOGin.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				validateData();
			}

			private String eEmail ="", ePassword ="";
			private void validateData() {

				//getting the dsta
				eEmail = username.getText().toString().trim();
				ePassword = password.getText().toString().trim();

				//Validate data
				if(!Patterns.EMAIL_ADDRESS.matcher(eEmail).matches()){
					Toast.makeText(login__activity.this, "Invalid email Pattern", Toast.LENGTH_SHORT).show();

				}
				else if (TextUtils.isEmpty(ePassword)){
					Toast.makeText(login__activity.this, "Enter Password", Toast.LENGTH_SHORT).show();

				}
				else{
					//data is validated, begin login
					loginUser();

				}

			}

			//function to handle user login
			private void loginUser() {
				progressDialog.setMessage("Logging user in..");
				progressDialog.show();

				//logging the user in
				firebaseAuth.signInWithEmailAndPassword(eEmail,ePassword)
						.addOnSuccessListener(new OnSuccessListener<AuthResult>() {
							@Override
							public void onSuccess(AuthResult authResult) {
								checkUser();
							}

							private void checkUser() {
								//check if user is user from realtime database
								//get current user
								progressDialog.setMessage("Checking users ");
								FirebaseUser firebaseUser = firebaseAuth.getCurrentUser();

								//Check in db
								DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Users");
								ref.child(firebaseUser.getUid())
								.addListenerForSingleValueEvent(new ValueEventListener() {
											@Override
											public void onDataChange(DataSnapshot snapshot) {
												progressDialog.dismiss();
												//get user type
												String userType = "" + snapshot.child("UserType").getValue();
												//check user type
												if (userType.equals("user")) {
													//this  user, open user splash to first window
													startActivity(new Intent(login__activity.this, SplashActivity1.class));
													finish();

												}
											}

											@Override
											public void onCancelled(DatabaseError error) {

											}
										});

							}
						})
						.addOnFailureListener(new OnFailureListener() {
							@Override
							public void onFailure(Exception e) {
								//login failed
								progressDialog.dismiss();
								Toast.makeText(login__activity.this, ""+e.getMessage(),Toast.LENGTH_SHORT).show();

							}
						});



			}
		});



	}


	}
	
	