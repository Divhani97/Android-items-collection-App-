package exportkit.xd;

import android.widget.Filter;

import java.util.ArrayList;

import exportkit.xd.adapters.AdapterCategory;
import exportkit.xd.adapters.AdapterItemAdmin;
import exportkit.xd.models.ModelItem;

public class FilterItem extends Filter {
    //arraylist we will search in
    ArrayList<ModelItem> filterList;

    AdapterItemAdmin  adapterItemAdmin;

    //cons

    public FilterItem(ArrayList<ModelItem> filterList, AdapterItemAdmin adapterItemAdmin) {
        this.filterList = filterList;
        this.adapterItemAdmin = adapterItemAdmin;
    }

    @Override
    protected FilterResults performFiltering(CharSequence constraint) {
        FilterResults results = new FilterResults();

        //value must not be null and empty
        if (constraint !=null && constraint.length()>0){

            //change to upper/lowe case ===avoid case sensitivity
            constraint = constraint.toString().toUpperCase();
            ArrayList<ModelItem> filteredModels = new ArrayList<>();

                for (int i=0; i<filterList.size(); i++){

                    //validate the data
                    if (filterList.get(i).getTitle().toUpperCase().contains(constraint)){
                        //add to the list
                        filteredModels.add(filterList.get(i));
                    }
            }
            results.count =filteredModels.size();
            results.values =filteredModels;
        }
        else{

            results.count =filterList.size();
            results.values =filterList;
        }
        return results;
    }

    @Override
    protected void publishResults(CharSequence constraint, FilterResults results) {
        //apply the filtered changes
        adapterItemAdmin.itemArrayList=(ArrayList<ModelItem>)results.values;

        //notify changes
        adapterItemAdmin.notifyDataSetChanged();
    }
}
