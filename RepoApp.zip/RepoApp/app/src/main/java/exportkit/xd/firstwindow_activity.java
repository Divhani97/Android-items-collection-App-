
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		untitled
	 *	@date 		1622117660948
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.xd;

import android.app.Activity;
import android.os.Bundle;


import android.os.Handler;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.TextView;
import android.widget.ImageView;
import android.content.Intent;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;


import exportkit.xd.adapters.AdapterCategory;
import exportkit.xd.models.Category;

	public class firstwindow_activity extends Activity {
     RecyclerView recyclerView; /*RvAdapter adapter;*/
		//
		private FloatingActionButton floatingButtonLogOut;

		//firebase authentication
		private FirebaseAuth firebaseAuth;

		private ArrayList<Category> arrayList; //array
		private AdapterCategory adapterCategory; //adapter

		private TextView UserTV;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.firstwindow);

		//init firebase auth
		firebaseAuth = FirebaseAuth.getInstance();

		recyclerView=findViewById(R.id.recycleView);
		recyclerView.setHasFixedSize(true);
		LinearLayoutManager manager=new GridLayoutManager(this,4);
		recyclerView.setLayoutManager(manager);
		ImageView CategoryPlus=findViewById(R.id.CategoryPlus);
		TextView food=findViewById(R.id.food);
		 UserTV=findViewById(R.id.UserTV);
		View rectangle_9=findViewById(R.id.rectangle_9);
		floatingButtonLogOut = findViewById(R.id.floatingButtonLogOut);
		loadCategories(); //function to get the categories
        displayUser();
 		//user log out event
		floatingButtonLogOut.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				firebaseAuth.signOut();
				displayUser();
			}
		});





		Button btnUploadItems=findViewById(R.id.btnUploadItems);
		CategoryPlus.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				startActivity(new Intent(firstwindow_activity.this,createcategory_activity.class));
			}
		});
		btnUploadItems.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				startActivity(new Intent(firstwindow_activity.this,ItemAddActivity.class));
			}
		});
		food.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				startActivity(new Intent(firstwindow_activity.this,ItemListAdminActivity.class));
			}
		});


		//custom code goes here
}

		private void displayUser() {
			FirebaseUser firebaseUser=firebaseAuth.getCurrentUser();
			if (firebaseUser==null){
				//not logged
				startActivity(new Intent(firstwindow_activity.this,login__activity.class));
			}else{

				//loged in
				String username= firebaseUser.getDisplayName();
				//set
				UserTV.setText(username);
			}

		}

		private void loadCategories() {
		//init arraylist
			arrayList = new ArrayList<>();

			//get all categories from firebase
			DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Categories");
			ref.addValueEventListener(new ValueEventListener() {
				@Override
				public void onDataChange(@NonNull DataSnapshot snapshot) {
					//clear array b4 adding data into it
					arrayList.clear();
					for (DataSnapshot ds: snapshot.getChildren()){
							Category model= ds.getValue(Category.class);
							//add to arraylist
							arrayList.add(model);
					}
					//setup the adapter
					adapterCategory  = new AdapterCategory(firstwindow_activity.this,arrayList);
					//set adapter to recyclerview
					recyclerView.setAdapter(adapterCategory);
				}

				@Override
				public void onCancelled(@NonNull DatabaseError error) {

				}
			});

		}
	}
	
	