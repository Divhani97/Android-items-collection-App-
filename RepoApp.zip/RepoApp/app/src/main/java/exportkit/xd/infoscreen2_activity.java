
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		untitled
	 *	@date 		1622117660948
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.xd;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;


import android.view.View;
import android.widget.TextView;
import android.widget.ImageView;

public class infoscreen2_activity extends Activity {

	
	private View _bg__infoscreen2_ek2;
	private TextView category_name;
	private TextView number_of_items;
	private View rectangle_13;
	private View rectangle_14_ek3;
	private View rectangle_6_ek4;
	private ImageView vector_ek18;
	private View rectangle_6_ek5;
	private ImageView vector_ek19;
	private TextView _1_ek1;
	private View ellipse_21_ek5;
	private ImageView arrow_1_ek5;
	private View rectangle_1_ek8;
	private TextView add;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.infoscreen2);

		
		_bg__infoscreen2_ek2 = (View) findViewById(R.id._bg__infoscreen2_ek2);
		category_name = (TextView) findViewById(R.id.category_name);
		number_of_items = (TextView) findViewById(R.id.number_of_items);
		rectangle_13 = (View) findViewById(R.id.rectangle_13);
		rectangle_14_ek3 = (View) findViewById(R.id.rectangle_14_ek3);
		rectangle_6_ek4 = (View) findViewById(R.id.rectangle_6_ek4);
		vector_ek18 = (ImageView) findViewById(R.id.vector_ek18);
		rectangle_6_ek5 = (View) findViewById(R.id.rectangle_6_ek5);
		vector_ek19 = (ImageView) findViewById(R.id.vector_ek19);

		ellipse_21_ek5 = (View) findViewById(R.id.ellipse_21_ek5);
		arrow_1_ek5 = (ImageView) findViewById(R.id.arrow_1_ek5);
		rectangle_1_ek8 = (View) findViewById(R.id.rectangle_1_ek8);
		add = (TextView) findViewById(R.id.add);
	
		
		//custom code goes here

		ellipse_21_ek5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				startActivity(new Intent(infoscreen2_activity.this,homescreen_activity.class));
			}
		});


		rectangle_1_ek8.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				startActivity(new Intent(infoscreen2_activity.this,infoscreen3_activity.class));
			}
		});

	}
}
	
	