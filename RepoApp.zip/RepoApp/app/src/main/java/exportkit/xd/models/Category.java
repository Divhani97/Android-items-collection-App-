package exportkit.xd.models;

public class Category {

    private String id,category,goalItem;
    long timestamp;


    //an empty constructor for db
    public Category() {
    }

   //constructor with parameters


    public Category(String id, String category, String goalItem, long timestamp) {
        this.id = id;
        this.category = category;
        this.goalItem = goalItem;
        this.timestamp = timestamp;
    }

    //getters and setters

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getGoalItem() {
        return goalItem;
    }

    public void setGoalItem(String goalItem) {
        this.goalItem = goalItem;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }
}
