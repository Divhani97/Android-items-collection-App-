package exportkit.xd;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

public class SplashActivity1 extends AppCompatActivity {
    //splash animation
    Animation zoom;
    ImageView splashImageView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash1);

        //animation handling
        zoom = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.zoom);
        splashImageView = findViewById(R.id.splashImageView);
        splashImageView.startAnimation(zoom);

        Handler h = new Handler();
        h.postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent= new Intent(getApplicationContext(),SplashActivity2.class);
                startActivity(intent);
                finish();
            }
        },4000);
    }
}