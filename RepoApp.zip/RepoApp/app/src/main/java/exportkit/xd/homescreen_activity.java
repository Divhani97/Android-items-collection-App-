
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		untitled
	 *	@date 		1622117660948
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.xd;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;


import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

	public class homescreen_activity extends Activity {

	
	private View _bg__homescreen_ek2;
	private ImageView ellipse_1;
	private ImageView ellipse_2;
	private TextView r;
	private TextView login;
	private ImageView ellipse_15;
	private ImageView ellipse_9;
	private ImageView ellipse_14;
	private ImageView ellipse_17;
	private ImageView ellipse_20;
	private ImageView ellipse_18;
	private ImageView ellipse_19;
	private ImageView ellipse_13;
	private TextView let_s_get_started;
	private View rectangle_1;
	private TextView sign_up;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.homescreen);

		
		_bg__homescreen_ek2 = (View) findViewById(R.id._bg__homescreen_ek2);
		ellipse_1 = (ImageView) findViewById(R.id.ellipse_1);
		ellipse_2 = (ImageView) findViewById(R.id.ellipse_2);
		r = (TextView) findViewById(R.id.r);
		login = (TextView) findViewById(R.id.login);
		ellipse_15 = (ImageView) findViewById(R.id.ellipse_15);
		ellipse_9 = (ImageView) findViewById(R.id.ellipse_9);
		ellipse_14 = (ImageView) findViewById(R.id.ellipse_14);
		ellipse_17 = (ImageView) findViewById(R.id.ellipse_17);
		ellipse_20 = (ImageView) findViewById(R.id.ellipse_20);
		ellipse_18 = (ImageView) findViewById(R.id.ellipse_18);
		ellipse_19 = (ImageView) findViewById(R.id.ellipse_19);
		ellipse_13 = (ImageView) findViewById(R.id.ellipse_13);
		let_s_get_started = (TextView) findViewById(R.id.let_s_get_started);
		rectangle_1 = (View) findViewById(R.id.rectangle_1);

	
		
		//custom code goes here

		login.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				startActivity(new Intent(homescreen_activity.this,login__activity.class));
			}
		});

		rectangle_1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				startActivity(new Intent(homescreen_activity.this,signup_activity.class));
			}
		});
}
}
	
	