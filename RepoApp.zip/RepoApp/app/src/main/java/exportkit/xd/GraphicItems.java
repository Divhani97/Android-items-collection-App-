package exportkit.xd;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;

import com.github.mikephil.charting.animation.Easing;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.PercentFormatter;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

public class GraphicItems extends AppCompatActivity {
private PieChart itemPieCjart;
    FirebaseAuth mAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_graphic_items);

        itemPieCjart= findViewById(R.id.itemPieChart);
        setupPieChart();
        loadProductChartData();

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference dbRef = database.getReference("Categories");//Categories

    }

    private void setupPieChart() {
        itemPieCjart.setDrawHoleEnabled(true);
        itemPieCjart.setUsePercentValues(true);
        itemPieCjart.setEntryLabelTextSize(12);
        itemPieCjart.setEntryLabelColor(Color.BLACK);
        itemPieCjart.setCenterTextSize(24);
        itemPieCjart.setCenterText("Categories");
        itemPieCjart.getDescription().setEnabled(false);


        Legend l = itemPieCjart.getLegend();
        l.setVerticalAlignment(Legend.LegendVerticalAlignment.TOP);
        l.setHorizontalAlignment(Legend.LegendHorizontalAlignment.RIGHT);
        l.setOrientation(Legend.LegendOrientation.VERTICAL);
        l.setDrawInside(false);
        l.setEnabled(true);
    }

    private void loadProductChartData() {
        ArrayList<PieEntry> entries= new ArrayList<>();
        entries.add(new PieEntry(0.0f,"Food"));
        entries.add(new PieEntry(0.05f,"Books"));
        entries.add(new PieEntry(0f,"Fashion"));
        entries.add(new PieEntry(0.01f,"Pets"));

        ArrayList<Integer> colors = new ArrayList<>();
        for (int color: ColorTemplate.MATERIAL_COLORS){
            colors.add(color);
        }

        for (int color: ColorTemplate.VORDIPLOM_COLORS){
            colors.add(color);
        }
        PieDataSet dataSet= new PieDataSet(entries,"keys");
        dataSet.setColors(colors);


        PieData data= new PieData(dataSet);
        data.setDrawValues(true);
        data.setValueFormatter(new PercentFormatter(itemPieCjart));
        data.setValueTextSize(10f);
        data.setValueTextColor(Color.BLACK);


        itemPieCjart.setData(data);
        itemPieCjart.invalidate();

        itemPieCjart.animateY(2000, Easing.EaseInBounce);

    }
}