
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		untitled
	 *	@date 		1622117660948
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.xd;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;


import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.HashMap;

	public class signup_activity extends Activity {


	private View ellipse_21_ek1;
	private View rectangle_1_ek2;
	private TextView username_ek1;
	private TextView password_ek1;
	private TextView email;
		//firebase auth
		private FirebaseAuth firebaseAuth;
		//Progress
		private ProgressDialog progressDialog;



		private static final String FILE_NAME = "example.txt";
		EditText mEditText;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.signup);

		//init firebase auth
		firebaseAuth = FirebaseAuth.getInstance();
		//setup progress dialog
		progressDialog = new ProgressDialog(this);
		progressDialog.setTitle("Please wait");
		progressDialog.setCanceledOnTouchOutside(false);

		ellipse_21_ek1 = (View) findViewById(R.id.ellipse_21_ek1);
		Button register = findViewById(R.id.register);
		EditText confirm_password  = findViewById(R.id.confirm_password);
		username_ek1 = (TextView) findViewById(R.id.username_ek1);
		password_ek1 = (TextView) findViewById(R.id.password_ek1);
		email = (TextView) findViewById(R.id.email);


			//click event for button register
		register.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				validateData();
			}
			//
			private String  username="" , eEmail ="", ePassword ="";
			private void validateData() {


				//getting the data
				username= username_ek1.getText().toString().trim();
				eEmail = email.getText().toString().trim();
				ePassword = password_ek1.getText().toString().trim();
				String confirmPassword = confirm_password.getText().toString().trim();

				//performing validation of the data
				if (TextUtils.isEmpty(username)){
					Toast.makeText(signup_activity.this,"Enter username", Toast.LENGTH_SHORT).show();
				}

				/*else if (TextUtils.isEmpty(eEmail)){
					Toast.makeText(signup_activity.this,"Enter Email", Toast.LENGTH_SHORT).show();
				}*/
				else if(!Patterns.EMAIL_ADDRESS.matcher(eEmail).matches()){
					Toast.makeText(signup_activity.this, "Invalid email Pattern", Toast.LENGTH_SHORT).show();

				}
				else if (TextUtils.isEmpty(ePassword)){
					Toast.makeText(signup_activity.this, "Enter Password", Toast.LENGTH_SHORT).show();

				}
				else if (TextUtils.isEmpty(confirmPassword)){
					Toast.makeText(signup_activity.this, "Confirm Password", Toast.LENGTH_SHORT).show();

				}
				else if (!ePassword.equals(confirmPassword)){
					Toast.makeText(signup_activity.this, "Passwords Don't Match",Toast.LENGTH_SHORT).show();
				}
				else {
					createUserAccount();
				}


			}

			private void createUserAccount() {
				//display progress
				progressDialog.setMessage("Creating account....");
				progressDialog.show();

				//create the user in db
				firebaseAuth.createUserWithEmailAndPassword(eEmail,ePassword)

						.addOnSuccessListener(new OnSuccessListener<AuthResult>() {
							@Override
							public void onSuccess(AuthResult authResult) {

								//account creation success
								//progressDialog.dismiss();
								//account update
								updateUserInfo();
								}

							private void updateUserInfo() {
								progressDialog.setMessage("Saving user info>>>");
								long timestamp = System.currentTimeMillis();
								//get current user

								String uid = firebaseAuth.getUid(); //get current user id

								//setup data to add in db
								HashMap<String,Object> hashMap= new HashMap<>();
								hashMap.put("uid",uid);
								hashMap.put("email", eEmail);
								hashMap.put("UserType","user"); //Will make admin in firebase
								hashMap.put("timestamp", timestamp);


								//set data to db
								DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Users");
								ref.child(uid)
										.setValue(hashMap)
										.addOnSuccessListener(new OnSuccessListener<Void>() {
											@Override
											public void onSuccess(Void unused) {

												//data added db
												progressDialog.dismiss();
												Toast.makeText(signup_activity.this,"Account created....", Toast.LENGTH_SHORT).show();
												//now have an account, start the first window
												startActivity(new Intent(signup_activity.this, SplashActivity1.class));
												finish();


											}
										})
										.addOnFailureListener(new OnFailureListener() {
											@Override
											public void onFailure(Exception e) {
												//data failed adding db
												progressDialog.dismiss();
												Toast.makeText(signup_activity.this, ""+e.getMessage(),Toast.LENGTH_SHORT).show();

											}
										});


							}
						})
						.addOnFailureListener(new OnFailureListener() {
							@Override
							public void onFailure(Exception e) {
								//Account creating failed
								progressDialog.dismiss();
								Toast.makeText(signup_activity.this,""+e.getMessage(),Toast.LENGTH_SHORT).show();
							}
						});


			}
		});




	}
}
	
	