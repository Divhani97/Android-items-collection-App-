package exportkit.xd.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import exportkit.xd.FilterItem;
import exportkit.xd.ItemListAdminActivity;
import exportkit.xd.R;
import exportkit.xd.models.Category;

public class AdapterCategory extends RecyclerView.Adapter<AdapterCategory.HolderCategory>  {
    //
    private Context context;
    private ArrayList<Category> arrayList;

  //instance of the filter class
    private Filterable filter;

    //cons
    public AdapterCategory(Context context, ArrayList<Category> arrayList) {
        this.context = context;
        this.arrayList = arrayList;

    }

    @NonNull
    @Override
    public HolderCategory onCreateViewHolder(@NonNull  ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.layout_item,parent,false); //row_category
        return new HolderCategory(view);

    }

    @Override
    public void onBindViewHolder(@NonNull  AdapterCategory.HolderCategory holder, int position) {
    Category model = arrayList.get(position);

    String category=model.getCategory();
    String id = model.getId();
    String goalItems= model.getGoalItem();
    long timestamp = model.getTimestamp();
    //set data
        holder.txt_name.setText(category);


        //handle item click , go to  pdf(item), pass category and categoryName ItemListAdminActivity
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(context, ItemListAdminActivity.class);
                intent.putExtra("categoryId",id);
                intent.putExtra("categoryTitle",category);
                context.startActivity(intent);
            }
        });

 }


    //

    @Override
    public int getItemCount() {
        return arrayList.size();
    }


    //view holder class to hold ui view s for layout_item.xml
    class HolderCategory extends RecyclerView.ViewHolder{
        //ui view for layout_item.xml
        TextView txt_name;
        public HolderCategory(@NonNull View itemView) {
            super(itemView);

            txt_name = itemView.findViewById(R.id.txt_name);
        }
    }
}
