
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		untitled
	 *	@date 		1622117660948
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.xd;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;


import android.view.View;
import android.widget.TextView;

public class infoscreen3_activity extends Activity {

	
	private View _bg__infoscreen3_ek2;
	private TextView almost_there_let_s_upload_an_item____;
	private View rectangle_1_ek10;
	private TextView add_ek2;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.infoscreen3);

		
		_bg__infoscreen3_ek2 = (View) findViewById(R.id._bg__infoscreen3_ek2);
		almost_there_let_s_upload_an_item____ = (TextView) findViewById(R.id.almost_there_let_s_upload_an_item____);
		rectangle_1_ek10 = (View) findViewById(R.id.rectangle_1_ek10);

	
		
		//custom code goes here

		rectangle_1_ek10.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				startActivity(new Intent(infoscreen3_activity.this,infoscreen4_activity.class));
			}
		});
	}
}
	
	