package exportkit.xd;

public class Constants {
    public static final long MAX_BYTES_ITEM= 50000000;//50MB
}
