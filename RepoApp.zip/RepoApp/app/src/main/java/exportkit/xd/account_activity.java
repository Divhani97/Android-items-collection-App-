
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		untitled
	 *	@date 		1622117660948
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.xd;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;


import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class account_activity extends Activity {

	
	private View _bg__account_ek2;
	private View ellipse_21_ek7;
	private ImageView arrow_1_ek7;
	private ImageView ellipse_23;
	private TextView name;
	private TextView email_ek1;
	private TextView password_ek2;
	private View rectangle_13_ek2;
	private TextView smith;
	private View rectangle_14_ek5;
	private View rectangle_15_ek1;
	private View rectangle_1_ek11;
	private View rectangle_2_ek1;
	private TextView update;
	private View rectangle_1_ek12;
	private View rectangle_2_ek2;
	private TextView delete_account;
	private TextView smith123_gmail_com;
	private TextView ___________________;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.account);

		
		_bg__account_ek2 = (View) findViewById(R.id._bg__account_ek2);
		ellipse_21_ek7 = (View) findViewById(R.id.ellipse_21_ek7);
		arrow_1_ek7 = (ImageView) findViewById(R.id.arrow_1_ek7);
		ellipse_23 = (ImageView) findViewById(R.id.ellipse_23);
		name = (TextView) findViewById(R.id.name);
		email_ek1 = (TextView) findViewById(R.id.email_ek1);
		password_ek2 = (TextView) findViewById(R.id.password_ek2);
		rectangle_13_ek2 = (View) findViewById(R.id.rectangle_13_ek2);
		smith = (TextView) findViewById(R.id.smith);
		rectangle_14_ek5 = (View) findViewById(R.id.rectangle_14_ek5);
		rectangle_15_ek1 = (View) findViewById(R.id.rectangle_15_ek1);
		rectangle_1_ek11 = (View) findViewById(R.id.rectangle_1_ek11);
		rectangle_2_ek1 = (View) findViewById(R.id.rectangle_2_ek1);

		rectangle_1_ek12 = (View) findViewById(R.id.rectangle_1_ek12);
		rectangle_2_ek2 = (View) findViewById(R.id.rectangle_2_ek2);

		smith123_gmail_com = (TextView) findViewById(R.id.smith123_gmail_com);
		___________________ = (TextView) findViewById(R.id.___________________);
	
		
		//custom code goes here
		ellipse_21_ek7.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				startActivity(new Intent(account_activity.this,firstwindow_activity.class));
			}
		});

	}
}
	
	