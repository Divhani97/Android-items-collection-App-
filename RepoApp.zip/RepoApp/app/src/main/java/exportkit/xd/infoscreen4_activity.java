
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		untitled
	 *	@date 		1622117660948
	 *	@title 		Page 1
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.xd;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;


import android.view.View;
import android.widget.TextView;
import android.widget.ImageView;

public class infoscreen4_activity extends Activity {

	
	private View _bg__infoscreen4_ek2;
	private View rectangle_10;
	private TextView choose_image___;
	private TextView select_or_add_a_category;
	private TextView description;
	private View rectangle_11;
	private View rectangle_12;
	private View rectangle_1_ek6;
	private TextView upload;
	private View rectangle_6_ek2;
	private ImageView vector_ek16;
	private TextView acquisition_date_ek2;
	private View rectangle_14_ek1;
	private TextView _2020_12_27_ek1;
	View btnUpload;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.infoscreen4);

		
		_bg__infoscreen4_ek2 = (View) findViewById(R.id._bg__infoscreen4_ek2);
		rectangle_10 = (View) findViewById(R.id.rectangle_10);
		choose_image___ = (TextView) findViewById(R.id.choose_image___);
		description = (TextView) findViewById(R.id.description);
		rectangle_11 = (View) findViewById(R.id.rectangle_11);
		 btnUpload = findViewById(R.id.btnUploadItemCateg);


		acquisition_date_ek2 = (TextView) findViewById(R.id.acquisition_date_ek2);

	
		
		//custom code goes here


		btnUpload.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				//startActivity(new Intent(infoscreen4_activity.this,uploadItems_activity.class));
			}
		});
	}
}


	
	